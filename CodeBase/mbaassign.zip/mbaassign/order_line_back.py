import sqlite3
from tkinter import messagebox
class Database:
    def __init__(self,db):
        self.conn = sqlite3.connect(db)
        self.cur = self.conn.cursor()
        self.cur.execute("CREATE TABLE IF NOT EXISTS `order_line` ( `id` INTEGER, `line_id` INTEGER PRIMARY KEY AUTOINCREMENT, `sku_id` INTEGER, `inven_id` INTEGER, `due` INTEGER, `price` INTEGER )")
        self.conn.commit()

    def insert(self,id,sku_id,inven_id, due, full):
        #the NULL parameter is for the auto-incremented id
        # self.cur.execute("SELECT qavail,rate,margin FROM `inventory` WHERE id = ? ",(inven_id,))
        # vals =self.cur.fetchall()
        # qavail = vals[0][0]
        # rate = vals[0][1]
        # margin =vals[0][2]
        # # print(qavail)
        # print(qavail,rate,margin)
        # due = int(due)
        # qavail =int(qavail)
        # full= int(full)

        # price =0
        # if(due<=qavail):
        #     qavail-=due
        #     full=due
        #     price=float(rate*(100+margin)*due)/100
        #     due=0
        # else:
        #     due-=qavail
        #     full+=qavail
        #     price=float(rate*(100+margin)*qavail)/100
        #     qavail=0

        # due = str(due)
        # qavail =str(qavail)
        # full= str(full)
        # price = str(price)
        # print(price)

        # self.cur.execute("UPDATE `inventory` SET qavail = ?  WHERE id = ? ",(qavail,inven_id))
        self.cur.execute("SELECT * FROM `order_header` WHERE order_id = ? ",(id,))
        vals =self.cur.fetchall()
        if(len(vals)==0):
            messagebox.showerror("Error", "No such Order ID exists")
            return
        print(vals)

        self.cur.execute("INSERT INTO `order_line` VALUES(?,NULL,?,?,?,?,?)", (id,sku_id, -1, due, 0,0))

        self.conn.commit()



    def view(self):
        self.cur.execute("SELECT * FROM `order_line` ")
        rows = self.cur.fetchall()
        return rows

    def search(self, id="", line_id="", sku_id="", inven_id="", due="", full=""):
        self.cur.execute("SELECT * FROM `order_line` WHERE id = ? OR line_id = ? OR sku_id = ? OR inven_id = ? OR due_qty = ? OR fulfilled = ?", (id, line_id, sku_id, inven_id, due, full))
        rows = self.cur.fetchall()
        #conn.close()
        return rows

    def delete(self,id):
        self.cur.execute("DELETE FROM `order_line` WHERE line_id = ?", (id,))
        self.conn.commit()
        #conn.close()

    def update(self,id,line_id,sku_id,inven_id, due, full,now):
        # print(id,name,type,phn1,phn2)
        # self.cur.execute("UPDATE `order_line` SET id = ?, sku_id = ?, inven_id = ?, due_qty = ?, fulfilled = ? WHERE line_id = ?", (id, sku_id, inven_id, due, full, line_id))
        # self.conn.commit()
        self.cur.execute("SELECT qavail,rate,margin FROM `inventory` WHERE id = ? ",(inven_id,))
        vals =self.cur.fetchall()
        qavail = vals[0][0]
        rate = vals[0][1]
        margin =vals[0][2]
        # print(qavail)
        print(qavail,rate,margin)
        due = int(due)
        qavail =int(qavail)
        full= int(full)
        now = int(now)

        self.cur.execute("SELECT price FROM `order_line` WHERE line_id = ? ",(line_id,))
        vals =self.cur.fetchall()
        print("ppp",vals)
        price = int(vals[0][0])
        print("price curr- > ",price)
        if(now<=qavail):
            qavail-=now
            due-=now
            full+=now
            price+=float(rate*(100+margin)*now)/100
        else:
            messagebox.showerror("Error", "Quantity not available in inventory")
            return
           
            # due-=qavail
            # full+=qavail
            # price=float(rate*(100+margin)*qavail)/100
            # qavail=0

        due = str(due)
        qavail =str(qavail)
        full= str(full)
        price = str(price)
        print(price)

        self.cur.execute("UPDATE `inventory` SET qavail = ?  WHERE id = ? ",(qavail,inven_id))
        
        self.cur.execute("UPDATE `order_line` SET id = ?, sku_id = ? , inven_id = ? ,due = ?, full = ? , price =? WHERE line_id =? ", (id,sku_id, inven_id, due, full,price,line_id))
        self.conn.commit()

    #destructor-->now we close the connection to our database here
    def __del__(self):
        self.conn.close()