import sys
import os
from tkinter import *
# from inven_back import  Database

# database = Database("sap.db")

class Window(object):
    def __init__(self,window):
        self.window = window
        self.window.wm_title("Home Screen")

        b1 = Button(window, text="Employee", width=12, command=self.emp_command)
        b1.grid(row=0, column=0)

        b2 = Button(window, text="Supplier", width=12, command=self.sup_command)
        b2.grid(row=1, column=0)

        b3 = Button(window, text="Customer", width=12, command=self.cus_command)
        b3.grid(row=2, column=0)

        b4 = Button(window, text="Inventory", width=12, command=self.inven_command)
        b4.grid(row=0, column=1)

        b5 = Button(window, text="Product", width=12, command=self.prod_command)
        b5.grid(row=1, column=1)

        b6 = Button(window, text="Product Category", width=12, command=self.prodcat_command)
        b6.grid(row=2, column=1)

        b7 = Button(window, text="Location", width=12, command=self.loc_command)
        b7.grid(row=0, column=2)

        b8 = Button(window, text="Order Header", width=12, command=self.order_head_command)
        b8.grid(row=1, column=2)

        b9 = Button(window, text="Order Line", width=12, command=self.order_line_command)
        b9.grid(row=2, column=2)

        b10 = Button(window, text="Log Out", width=12, command=self.logout)
        b10.grid(row=2, column=3)

    def emp_command(self):
        os.system('python3 emp.py')

    def sup_command(self):
        os.system('python3 sup.py')

    def cus_command(self):
        os.system('python3 cus.py')
    def inven_command(self):
        os.system('python3 inven.py')
    def prod_command(self):
        os.system('python3 prod.py')
    def prodcat_command(self):
        os.system('python3 procat.py')
    def loc_command(self):
        os.system('python3 loc.py')
    def order_head_command(self):
        os.system('python3 order_header.py')
    def order_line_command(self):
        os.system('python3 order_line.py')
    def logout(self):
        window.destroy()
        os.system('python3 login.py')
#code for the GUI (front end)
window = Tk()
# Window(window)

# window.mainloop()
def main():
  Window(window)
  window.mainloop()

if __name__ == "__main__":
  main()